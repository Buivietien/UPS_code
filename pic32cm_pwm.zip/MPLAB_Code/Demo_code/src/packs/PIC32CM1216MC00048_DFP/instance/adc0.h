/*
 * Instance header file for PIC32CM1216MC00048
 *
 * Copyright (c) 2022 Microchip Technology Inc. and its subsidiaries.
 *
 * Subject to your compliance with these terms, you may use Microchip software and any derivatives
 * exclusively with Microchip products. It is your responsibility to comply with third party license
 * terms applicable to your use of third party software (including open source software) that may
 * accompany Microchip software.
 *
 * THIS SOFTWARE IS SUPPLIED BY MICROCHIP "AS IS". NO WARRANTIES, WHETHER EXPRESS, IMPLIED OR STATUTORY,
 * APPLY TO THIS SOFTWARE, INCLUDING ANY IMPLIED WARRANTIES OF NON-INFRINGEMENT, MERCHANTABILITY, AND
 * FITNESS FOR A PARTICULAR PURPOSE.
 *
 * IN NO EVENT WILL MICROCHIP BE LIABLE FOR ANY INDIRECT, SPECIAL, PUNITIVE, INCIDENTAL OR CONSEQUENTIAL
 * LOSS, DAMAGE, COST OR EXPENSE OF ANY KIND WHATSOEVER RELATED TO THE SOFTWARE, HOWEVER CAUSED, EVEN IF
 * MICROCHIP HAS BEEN ADVISED OF THE POSSIBILITY OR THE DAMAGES ARE FORESEEABLE. TO THE FULLEST EXTENT
 * ALLOWED BY LAW, MICROCHIP'S TOTAL LIABILITY ON ALL CLAIMS IN ANY WAY RELATED TO THIS SOFTWARE WILL NOT
 * EXCEED THE AMOUNT OF FEES, IF ANY, THAT YOU HAVE PAID DIRECTLY TO MICROCHIP FOR THIS SOFTWARE.
 *
 */

/* file generated from device description version 2021-03-23T20:32:05Z */
#ifndef _PIC32CMMC00_ADC0_INSTANCE_
#define _PIC32CMMC00_ADC0_INSTANCE_


/* ========== Instance Parameter definitions for ADC0 peripheral ========== */
#define ADC0_DMAC_ID_RESRDY                      (36)       /* index of DMA RESRDY trigger */
#define ADC0_EXTCHANNEL_MSB                      (11)       /* Number of external channels */
#define ADC0_GCLK_ID                             (28)       /* Index of Generic Clock */
#define ADC0_INT_CH30                            (0)        /* Select OPAMP or CTAT on Channel 30 */
#define ADC0_MASTER_SLAVE_MODE                   (1)        /* ADC Master/Slave Mode */
#define ADC0_LOAD_CALIB                          (1)        /* CALIB register to be loaded from NVM */
#define ADC0_INSTANCE_ID                         (81)       /* Instance index for ADC0 */

#endif /* _PIC32CMMC00_ADC0_INSTANCE_ */
